const db = require("../models");

const Theater = db.theaters;
const Screening = db.screenings;
const Movie = db.movies;
const Seat = db.seats;
const User = db.members;

const {QueryTypes} = require("sequelize");
const sequelize = require("sequelize");





const theaterID = async (req, res) => {
    try {
       
        const thea = await Theater.findOne({ where: { theater_id: req.body.theaterId }, raw: true });

        res.send(thea);
    } catch (error) {
        // 오류 처리
    }
};

const titleID = async (req, res) => {
    try {
        
        const theaterName = req.body.theaterName;
     

        const query = `
      SELECT t.theater_id, t.theater_location, t.theater_name, m.movie_id, m.movie_title
      FROM theater AS t
      LEFT JOIN screening AS s ON t.theater_id = s.theater_id
      LEFT JOIN movie AS m ON s.movie_id = m.movie_id
      WHERE t.theater_name = :theaterName
      `;
        const replacements = { theaterName: theaterName };


        const movieList = await db.sequelize.query(query, {
            replacements,
            type: sequelize.QueryTypes.SELECT
        });


        

        res.send(movieList);



    } catch (error) {
        // 오류 처리
    }
};



const screenTime = async (req, res) => {
    try {
        
        const screens = await Screening.findAll({
            where: { movie_id: req.body.movieId },
             // screen_time만 조회하도록 attributes 설정
            raw: true
        });

   
        res.send(screens);
    } catch (error) {
        // 오류 처리
    }
};

const seatser = async (req, res) => {
    try {
   const seata = await Theater.findOne ({
            where: { theater_name : req.body.theater_name}, raw: true
        });
        
        console.log(seata.theater_id)
        console.log(req.body)
        if (seata){ 
            const seatInfo = await Seat.findAll ({
                where: { theater_id: seata.theater_id }, raw: true
            
            });
            console.log(seatInfo);
            res.send(seatInfo);
        }
        

    } catch (error){
        console.log(error);

    }
}


module.exports = {
    theaterID,
    titleID,
    screenTime,
    seatser
    // getScreenings
};